/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */
#define MODBUS_RS 1  //������  1-->����RS485  0-->����RS232
#define MODBUS_MODE 0 //��Ϊ�������Ǵӻ� 1-->����  0-->�ӻ�
/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define RS485_D_R_Pin GPIO_PIN_6
#define RS485_D_R_GPIO_Port GPIOE
#define KEY3_Pin GPIO_PIN_0
#define KEY3_GPIO_Port GPIOC
#define KEY3_EXTI_IRQn EXTI0_IRQn
#define KEY2_Pin GPIO_PIN_1
#define KEY2_GPIO_Port GPIOC
#define KEY2_EXTI_IRQn EXTI1_IRQn
#define KEY1_Pin GPIO_PIN_2
#define KEY1_GPIO_Port GPIOC
#define KEY1_EXTI_IRQn EXTI2_IRQn
#define SEL0_Pin GPIO_PIN_0
#define SEL0_GPIO_Port GPIOB
#define SEL1_Pin GPIO_PIN_1
#define SEL1_GPIO_Port GPIOB
#define SEL2_Pin GPIO_PIN_2
#define SEL2_GPIO_Port GPIOB
#define A_Pin GPIO_PIN_8
#define A_GPIO_Port GPIOE
#define B_Pin GPIO_PIN_9
#define B_GPIO_Port GPIOE
#define C_Pin GPIO_PIN_10
#define C_GPIO_Port GPIOE
#define D_Pin GPIO_PIN_11
#define D_GPIO_Port GPIOE
#define E_Pin GPIO_PIN_12
#define E_GPIO_Port GPIOE
#define F_Pin GPIO_PIN_13
#define F_GPIO_Port GPIOE
#define G_Pin GPIO_PIN_14
#define G_GPIO_Port GPIOE
#define H_Pin GPIO_PIN_15
#define H_GPIO_Port GPIOE
#define LED_SEL_Pin GPIO_PIN_3
#define LED_SEL_GPIO_Port GPIOB
/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
