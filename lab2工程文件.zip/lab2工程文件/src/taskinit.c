#include <rtx51tny.h>
#include <sys_support.h>

xdata u8 seg0_to_9[11] = {0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F};
xdata u8 led_ryg[4] = {0xc0, 0x18, 0x03};
xdata u8 x1,x2,state;

void task_init(void) _task_ INIT
{
    seg_led_init();
    button_init();
		InitADC_light();

    led_print(0);
//    all_seg_print(hello);

    // SYSTEM PROCESS TASK REGISTER
    os_create_task(SCHEDULER);
    os_create_task(TIME1MS);


    // USER PROCESS TASK REGISTER
    os_create_task(RYGTIMES);
		os_create_task(EMERGENCY);
    os_create_task(CROWDED);
	  os_create_task(MIDNIGHT);
//    os_create_task(LESSCROWDED);

    os_delete_task(INIT);
}

// SYSTEM PROCESS BEGIN

void scheduler(void)    _task_ SCHEDULER    { events_awake_scheduler_task(); }
void time1ms(void)      _task_ TIME1MS      { time1ms_task();                }

// SYSTEM PROCESS END

// USER PROCESS BEGIN
// You can program it to run like processes, rather than describing it in a state machine manner.
xdata i8 turn = 0;
xdata i8 Red0 = RED, Yellow0 = YELLOW, Green0 = GREEN;
xdata i8 red = RED, yellow = YELLOW, green = GREEN;
void TrafficLightState(void) _task_ RYGTIMES  //3: 红绿灯倒计时切换
{	
    while (1) {
        os_event_wait(EVENT_TIME1S);//等待事件，只有这些事件发生才会继续执行后面代码
				if(red < 0)
				{
					if(green < 0)
					{
						if(yellow < 0)
						{
							red = Red0;
							yellow = Yellow0;
							green = Green0;
						}
						else
						{
							x1 = yellow%10;
							x2 = yellow/10;
							state = 1;
							single_seg_print(4,seg0_to_9[x1]);
							single_seg_print(3,seg0_to_9[x2]);
							if(turn == 1)
							{
								led_print(led_ryg[state]);
								turn = 0;
							}
							else
							{
								led_print(0);
								turn = 1;
							}
							yellow--;
						}
					}
					else
					{
						x1 = green%10;
						x2 = green/10;
						state = 2;
						single_seg_print(7,seg0_to_9[x1]);
						single_seg_print(6,seg0_to_9[x2]);
						led_print(led_ryg[state]);
						green--;
					}
				}
				else
				{
					green = Green0;
					x1 = red%10;
					x2 = red/10;
					state = 0;
					single_seg_print(1,seg0_to_9[x1]);
					single_seg_print(0,seg0_to_9[x2]);
					led_print(led_ryg[state]);
					red--;
				}
    }
}


void EmergencyPedestrian(void) _task_ EMERGENCY  //4: 紧急行人路过（可以按下key1改变时间）
{
	while(1)
	{
		os_event_wait(EVENT_KEY1_PRESS);//等待事件，只有这些事件发生才会继续执行后面代码
		if((red < 0)&&(green > 10))
			green = 0;
	}
}


xdata mode = 0;
xdata u8 seg_mode0  = 0x40;
xdata u8 seg_mode10 = 0x01;
xdata u8 seg_mode11 = 0x08;
void Crowded(void) _task_ CROWDED  //5: 行人较多，拥挤时刻（可以按下key2，使其red_times增加，green_times减少）
{
	while(1)
	{
		os_event_wait(EVENT_KEY2_PRESS);//等待事件，只有这些事件发生才会继续执行后面代码
		if(mode == 0)
		{
			mode = 1;
			Green0 = 15;
			Red0   = 30;
			single_seg_print(2,seg_mode10);
			single_seg_print(5,seg_mode11);
		}
		else
		{
			mode = 0;
			Green0 = GREEN;
			Red0   = RED;
			single_seg_print(2,seg_mode0);
			single_seg_print(5,seg_mode0);
		}
	}
}

//void LessCrowded(void) _task_ LESSCROWDED  //5: 行人较少（可以按下key2，使其red_times减少，green_times增加）
//{
//	while(1)
//	{
//		os_event_wait(EVENT_KEY2_PRESS);//等待事件，只有这些事件发生才会继续执行后面代码
//		if((red < 0)&&(green > 10))
//		Green = 30;
//		Red   = 15;
//	}
//}
void Midnight(void) _task_ MIDNIGHT  //6: 半夜
{
	while(1)
	{
		os_event_wait(EVENT_MIDNIGHT);//等待事件，只有这些事件发生才会继续执行后面代码
		green  = -1;
		red	   = -1;
		yellow = -1;
		led_print(0x18);
		single_seg_print(0,seg0_to_9[0]);
		single_seg_print(1,seg0_to_9[0]);
		single_seg_print(3,seg0_to_9[0]);
		single_seg_print(4,seg0_to_9[0]);
		single_seg_print(6,seg0_to_9[0]);
		single_seg_print(7,seg0_to_9[0]);
	}
}

// USER PROCESS END