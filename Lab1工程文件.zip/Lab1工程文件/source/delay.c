#include <STC15F2K60S2.H>

void delay(unsigned char xms)		
{
	unsigned char i, j;
  while(xms)
	{
		xms--;
		i = 12;
		j = 169;
		do
		{
			while (--j);
		} while (--i);
	}
}
