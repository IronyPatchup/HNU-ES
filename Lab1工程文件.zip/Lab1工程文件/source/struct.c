#include <STC15F2K60S2.H>
#include "delay.h"
#include "StepMotor.h"
#include "sys.h"

#define S1 P41
#define S2 P42
#define S3 P43
#define S4 P44


xdata Motor motor1,motor2,motor3;

void StepMotorInit(char motor) {
    switch (motor) {
        case 1: // ��ʼ�����1
            S1 = 0;
            S2 = 0;
            S3 = 0;
            S4 = 0;
            break;
        case 2: // ��ʼ�����2
            // ������Ҫ���ӳ�ʼ���߼�
            break;
        case 3: // ��ʼ�����3
            // ������Ҫ���ӳ�ʼ���߼�
            break;
    }
}


void StepMotorDrv(Motor* motor)      //��������
{
	unsigned char delay_time;
	char direction;
	unsigned char speed,steps=motor->steps;
	unsigned char i;
	for(i=0; i<steps; i++)
	{
		direction = motor->direction;
		speed     = motor->speed;
		steps     = motor->steps;
		delay_time = 255/speed;
		if(direction == 1)
		{
			S1 = 1; S2 = 0; S3 = 0; S4 = 0;
			delay(delay_time);
			S1 = 0; S2 = 1; S3 = 0; S4 = 0;
			delay(delay_time);
			S1 = 0; S2 = 0; S3 = 1; S4 = 0;
			delay(delay_time);
			S1 = 0; S2 = 0; S3 = 0; S4 = 1;
			delay(delay_time);
		}
		else if(direction == -1)
		{
			S1 = 0; S2 = 0; S3 = 0; S4 = 1;
			delay(delay_time);
			S1 = 0; S2 = 0; S3 = 1; S4 = 0;
			delay(delay_time);
			S1 = 0; S2 = 1; S3 = 0; S4 = 0;
			delay(delay_time);
			S1 = 1; S2 = 0; S3 = 0; S4 = 0;
			delay(delay_time);
		}
	}
	
}

	



// ���õ������
void StepMotorSetDirection(Motor *motor, char direction) {
    motor->direction = direction;
}

// ���õ���ٶ�
void StepMotorSetSpeed(Motor *motor, unsigned char speed) {
    motor->speed = speed;
}

// ���õ������
void StepMotorSetSteps(Motor *motor, unsigned char steps) {
    motor->steps = steps;
}
