#include <STC15F2K60S2.H>


#define S1 = P41
#define S2 = P42
#define S3 = P43
#define S4 = P44


