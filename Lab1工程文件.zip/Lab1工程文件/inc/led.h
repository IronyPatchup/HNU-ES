#ifndef __LED_H__
#define __LED_H__

void LED_init();

#endif