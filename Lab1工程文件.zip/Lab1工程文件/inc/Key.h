#ifndef __KEY_H__
#define __KEY_H__


unsigned char key();

#endif