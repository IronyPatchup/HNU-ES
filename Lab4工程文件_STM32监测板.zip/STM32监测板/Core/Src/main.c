/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "i2c.h"
#include "rtc.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "modbus.h"
#include "stdio.h"
#include "display.h"
#include "event_time.h"
#include "AT24C02.h"
#include "rda5807fp.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

#define  Time_Address  33



void SystemClock_Config(void);

 
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */


/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

//ch(1-6Chnnal),times(��ȡ����)
uint32_t ADC_Get_Average(uint8_t ch,uint8_t times)
{
	ADC_ChannelConfTypeDef sConfig;		//ͨ����ʼ��
	uint32_t value_sum=0;
	uint8_t i;
	switch(ch)							//ѡ��ADCͨ��
	{
		case 0:sConfig.Channel = ADC_CHANNEL_0;break;
		case 1:sConfig.Channel = ADC_CHANNEL_1;break;
		case 2:sConfig.Channel = ADC_CHANNEL_2;break;
		case 3:sConfig.Channel = ADC_CHANNEL_3;break;
		case 4:sConfig.Channel = ADC_CHANNEL_4;break;
		case 5:sConfig.Channel = ADC_CHANNEL_5;break;
		case 6:sConfig.Channel = ADC_CHANNEL_6;break;
		case 7:sConfig.Channel = ADC_CHANNEL_7;break;
		case 8:sConfig.Channel = ADC_CHANNEL_8;break;
		case 9:sConfig.Channel = ADC_CHANNEL_9;break;
		case 10:sConfig.Channel = ADC_CHANNEL_10;break;
		case 11:sConfig.Channel = ADC_CHANNEL_11;break;
		case 12:sConfig.Channel = ADC_CHANNEL_12;break;
		case 13:sConfig.Channel = ADC_CHANNEL_13;break;
		case 14:sConfig.Channel = ADC_CHANNEL_14;break;
		case 15:sConfig.Channel = ADC_CHANNEL_15;break;
	}
	sConfig.SamplingTime = ADC_SAMPLETIME_239CYCLES_5;		//��������239.5����
	sConfig.Rank = 1;
	HAL_ADC_ConfigChannel(&hadc1,&sConfig);
	for(i=0;i<times;i++)
	{
		HAL_ADC_Start(&hadc1);								//����ת��
		HAL_ADC_PollForConversion(&hadc1,30);				//�ȴ�ת������
		value_sum += HAL_ADC_GetValue(&hadc1);				//���
		HAL_ADC_Stop(&hadc1);								//ֹͣת��
	}
	return value_sum/times;									//����ƽ��ֵ
}


void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) //������ɻص�����
{
	if(huart == &huart1)
	{
		if(modbus.mode == 1)
		{
			printf("�յ�����֡����ʼ����\n");
			HOST_ModbusRX();//����֡����		
		}
		else if(modbus.mode == 0)
		{
//			printf("��ʼ��������֡\n");
			Modbus_Event();
			MODBUS_Init_flag = 0;
		}	
	}

	if(huart == &huart2)
	{
		if(modbus.mode == 1)
		{
			printf("�յ�����֡����ʼ����\n");
			HOST_ModbusRX();//����֡����		
		}
		else if(modbus.mode == 0)
		{
			printf("��ʼ��������֡\n");
			Modbus_Event();
			MODBUS_Init_flag = 0;
		}	
	}

}

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart) //������ɻص�����
{
	if(huart == &huart1)
	{
		if(modbus.mode == 1)
		{
			printf("�ȴ��ӻ���Ӧ����֡\n");
			//HAL_UART_Receive(&huart1, modbus.rcbuf, 9,HAL_MAX_DELAY);
			printf("recount: %d\n",modbus.recount);
			HAL_UART_Receive_IT(&huart1,modbus.rcbuf,modbus.recount);	
		}
		else if(modbus.mode == 0)
		{
//			printf("�ѻظ�\n");
		}
	}
	if(huart == &huart2)
	{
		if(modbus.mode == 1)
		{
			printf("�ȴ��ӻ���Ӧ����֡\n");
			//HAL_UART_Receive(&huart1, modbus.rcbuf, 9,HAL_MAX_DELAY);
			printf("recount: %d\n",modbus.recount);
			//485�����ж�
			HAL_GPIO_WritePin(RS485_D_R_GPIO_Port,RS485_D_R_Pin,0);
			HAL_UART_Receive_IT(&huart2,modbus.rcbuf,modbus.recount);	
		}
		else if(modbus.mode == 0)
		{
			printf("�ѻظ�\n");
		}
	}

}


int KeyMode = 0; //��¼�������ĸ���������

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	if(GPIO_Pin == KEY1_Pin)
	{
		KeyMode = 1;
		HAL_TIM_Base_Start_IT(&htim2);//����Tim2�жϽ��м�ʱ����
	}
	
	else if(GPIO_Pin == KEY2_Pin)
	{
		KeyMode = 2;
		HAL_TIM_Base_Start_IT(&htim2);//����Tim2���м�ʱ����	
	}
	
	else if(GPIO_Pin == KEY3_Pin)
	{
		KeyMode = 3;
		HAL_TIM_Base_Start_IT(&htim2);//����Tim2���м�ʱ����	
	}
}

int FM_state = 0;
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim) 
{
	if(htim == &htim2)//Tim2ʵ�ְ���������20ms����жϣ�
	{
		HAL_TIM_Base_Stop_IT(&htim2);	//�ر�Tim2�ж�	
		switch(KeyMode){
			case 1:
				if(HAL_GPIO_ReadPin(KEY1_GPIO_Port,KEY1_Pin)==0)
				{//Key1���º�ʵ�ֵĹ���
					if(Mode_Display == 0) Mode_Display = 1;
					else if(Mode_Display == 1) Mode_Display = 0;					
				}
				break;
			case 2:
				if(HAL_GPIO_ReadPin(KEY2_GPIO_Port,KEY2_Pin)==0)
				{//Key2���º�ʵ�ֵĹ���
					/*
					�洢�������¶�/���գ������쳣ʱ��ʱ��
					*/
						uint8_t data0[3];
						data0[0] = Reg[5] = Reg[0]&0xff;
						data0[1] = Reg[6] = Reg[1]&0xff;
						data0[2] = Reg[7] = Reg[2]&0xff;			
						AT24C02_write(Time_Address, data0, 3);	
				}
				break;
			case 3:
				if(HAL_GPIO_ReadPin(KEY3_GPIO_Port,KEY3_Pin)==0)
				{//Key3���º�ʵ�ֵĹ���
					/*
					����/�ر�FM
					*/
					if(FM_state == 0)
					{
						FM_state = 1;
						FM_Start();
					}
					else if(FM_state == 1)
					{
						FM_state = 0;
						FM_Stop();
					}
				}
				break;
		}
	}
	
	else if(htim == &htim3) //Tim3�жϺ���ʵ��ÿ1ms����RTCʱ�䵽Reg�Ĵ�����
	{
		//����RTC��Reg�Ĵ�����
		RTC_TimeTypeDef sTime;
	  RTC_DateTypeDef sDate;
		HAL_RTC_GetTime(&hrtc, &sTime, RTC_FORMAT_BIN);
    /* Get the RTC current Date */
    HAL_RTC_GetDate(&hrtc, &sDate, RTC_FORMAT_BIN);
 		Reg[0] = sTime.Seconds;
		Reg[1] = sTime.Minutes;	
		Reg[2] = sTime.Hours;	

		//����ADC���¶Ⱥ͹��յ�Reg�Ĵ�����
		uint32_t Adc1 = ADC_Get_Average(15,1); //�¶�δת��ǰ��ADCֵ
		Reg[3] = Adc1;
		uint32_t Adc2 = ADC_Get_Average(14,1); //����δת��ǰ��ADCֵ
		Reg[4] = Adc2;		
		}
}



/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
	HAL_SYSTICK_Config(71999); //����SysTick���жϺ���ʱ��Ϊ1ms
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_RTC_Init();
  MX_ADC1_Init();
  MX_I2C1_Init();
  MX_I2C2_Init();
  /* USER CODE BEGIN 2 */
	HAL_TIM_Base_Start_IT(&htim3);
	Modbus_Init();
	RDA5807FP_Init();
//	//ROM���Դ���
//	uint8_t data1[3];
//		//AT24C02_write(Time_Address, data1, 2);
//		int readit = AT24C02_read (Time_Address, data1, 3);
//		if(readit == 0)
//			printf("Time: %d:%d:%d\n",data1[2],data1[1],data1[0]);
//		else
//			printf("read error\n");

	//FM_Start();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
			if (Flag_1mS!=0)   { Flag_1mS = 0;    Func_1mS();} 
			if (Flag_20mS!=0)  { Flag_20mS = 0;   Func_20mS(); } 
			if (Flag_1S!=0)    { Flag_1S = 0;     Func_1S();} 
			if (Flag_1Min!=0)  { Flag_1Min = 0;   Func_1Min();} 
			if (Flag_1Hour!=0) { Flag_1Hour = 0;  Func_1Hour();} 				
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSI|RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL6;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_RTC|RCC_PERIPHCLK_ADC;
  PeriphClkInit.RTCClockSelection = RCC_RTCCLKSOURCE_LSI;
  PeriphClkInit.AdcClockSelection = RCC_ADCPCLK2_DIV6;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

