#include <STC15F2K60S2.H>
#include "delay.h"
#include "StepMotor.h"
#include "sys.h"
#include "displayer.h"

#define S1 P41
#define S2 P42
#define S3 P43
#define S4 P44

#define LED1 P00
#define LED2 P01
#define LED3 P02
#define LED4 P03

#define LED5 P04
#define LED6 P05
#define LED7 P06
#define LED8 P07

xdata Motor motor1, motor2, motor3;

void StepMotorInit(char motor) {
    switch (motor) {
        case 1: // ��ʼ�����1
            S1 = 0;
            S2 = 0;
            S3 = 0;
            S4 = 0;
            break;
        case 2: // ��ʼ�����2��LED ģ�⣩
            LED1 = 0;
            LED2 = 0;
            LED3 = 0;
            LED4 = 0;
            break;
        case 3: // ��ʼ�����3��LED ģ�⣩
            LED5 = 0;
            LED6 = 0;
            LED7 = 0;
            LED8 = 0;
            break;
    }
}

void StepMotorDrv(Motor* motor) {
    unsigned char delay_time;
    char direction;
    unsigned char speed, steps = motor->steps;
    unsigned char i;

    for (i = 0; i < steps; i++) {
        direction = motor->direction;
        speed = motor->speed;
				steps = motor->steps;
        delay_time = 255 / speed;

        if (direction == 1) {
            // ���Ƶ��1
            if (motor == &motor1) {
                S1 = 1; S2 = 0; S3 = 0; S4 = 0;
                delay(delay_time);
                S1 = 0; S2 = 1; S3 = 0; S4 = 0;
                delay(delay_time);
                S1 = 0; S2 = 0; S3 = 1; S4 = 0;
                delay(delay_time);
                S1 = 0; S2 = 0; S3 = 0; S4 = 1;
                delay(delay_time);
            }
            // ���Ƶ��2 (LED ģ��)
            else if (motor == &motor2) {
                LED1 = 1; LED2 = 0; LED3 = 0; LED4 = 0;
                delay(delay_time);
                LED1 = 0; LED2 = 1; LED3 = 0; LED4 = 0;
                delay(delay_time);
                LED1 = 0; LED2 = 0; LED3 = 1; LED4 = 0;
                delay(delay_time);
                LED1 = 0; LED2 = 0; LED3 = 0; LED4 = 1;
                delay(delay_time);
            }
            // ���Ƶ��3 (LED ģ��)
            else if (motor == &motor3) {
                LED5 = 1; LED6 = 0; LED7 = 0; LED8 = 0;
                delay(delay_time);
                LED5 = 0; LED6 = 1; LED7 = 0; LED8 = 0;
                delay(delay_time);
                LED5 = 0; LED6 = 0; LED7 = 1; LED8 = 0;
                delay(delay_time);
                LED5 = 0; LED6 = 0; LED7 = 0; LED8 = 1;
                delay(delay_time);
            }
        } 
        else if (direction == -1) {
            // ���Ƶ��1
            if (motor == &motor1) {
                S1 = 0; S2 = 0; S3 = 0; S4 = 1;
                delay(delay_time);
                S1 = 0; S2 = 0; S3 = 1; S4 = 0;
                delay(delay_time);
                S1 = 0; S2 = 1; S3 = 0; S4 = 0;
                delay(delay_time);
                S1 = 1; S2 = 0; S3 = 0; S4 = 0;
                delay(delay_time);
            }
            // ���Ƶ��2 (LED ģ��)
            else if (motor == &motor2) {
                LED1 = 0; LED2 = 0; LED3 = 0; LED4 = 1;
                delay(delay_time);
                LED1 = 0; LED2 = 0; LED3 = 1; LED4 = 0;
                delay(delay_time);
                LED1 = 0; LED2 = 1; LED3 = 0; LED4 = 0;
                delay(delay_time);
                LED1 = 1; LED2 = 0; LED3 = 0; LED4 = 0;
                delay(delay_time);
            }
            // ���Ƶ��3 (LED ģ��)
            else if (motor == &motor3) {
                LED5 = 0; LED6 = 0; LED7 = 0; LED8 = 1;
                delay(delay_time);
                LED5 = 0; LED6 = 0; LED7 = 1; LED8 = 0;
                delay(delay_time);
                LED5 = 0; LED6 = 1; LED7 = 0; LED8 = 0;
                delay(delay_time);
                LED5 = 1; LED6 = 0; LED7 = 0; LED8 = 0;
                delay(delay_time);
            }
        }
    }
}

void StepMotor1()
{
		StepMotorDrv(&motor1);
}

void StepMotor2()
{
		StepMotorDrv(&motor2);
}

void StepMotor3()
{
		StepMotorDrv(&motor3);
}



// ���õ������
void StepMotorSetDirection(Motor *motor, char direction) {
    motor->direction = direction;
}

// ���õ���ٶ�
void StepMotorSetSpeed(Motor *motor, unsigned char speed) {
    motor->speed = speed;
		sys_Disp.Text[0] = motor->speed/100;
		sys_Disp.Text[1] = motor->speed/10;
		sys_Disp.Text[2] = motor->speed%10;
}

// ���õ������
void StepMotorSetSteps(Motor *motor, unsigned char steps) {
    motor->steps = steps;
}
