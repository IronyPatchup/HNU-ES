#ifndef __ADC_H__
#define __ADC_H__

void InitADC();
void Divide3and5();




#endif